RUS v11.62 -> v11.62.1 COPY-ONLY PATCH
========================================
Purpose: let the deployment team copy only application/source changes without
overwriting their existing CI/CD customizations.

Copy the contents of this patch over the team's v11.62 source tree, preserving paths.

IMPORTANT: three deployment-managed files are intentionally NOT included:
- AgenticDataDisparity.API/.gitlab-ci.yml
- AgenticDataDisparity.API/ci-cd/templates/base-pipeline.yml
- AgenticDataDisparity.API/Dockerfile

Merge the small required changes from RUS_v11_62_to_v11_62_1_CICD_MERGE_NOTES.txt
into the deployment team's versions instead of overwriting them.

Then delete:
- scripts/verify_runtime_v11_62.ps1

Current release: 11.62.1
Direct-copy updated/new files: 37
CI/CD-managed files to merge manually: 3
Obsolete file to delete: 1
