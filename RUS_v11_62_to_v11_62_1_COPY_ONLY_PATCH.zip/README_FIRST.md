# RUS Agentic Data Disparity v11.62.1 — Deployment-Fixed Adaptive Final

This is the complete production-oriented RUS Data Disparity source tree based on the validated v11.60 integration baseline, with an additional **PII-minimized adaptive execution-memory layer and bounded recursive self-improvement (RSI)** for the Agentic API.

The RSI implementation is intentionally constrained. It can learn which of a small set of pre-approved, evidence-only reasoning strategies performs best from prior execution outcomes. It **cannot edit source code, invent new tools/endpoints, change data-truth rules, change source-write permissions, alter profile approvals, bypass Dry Run / the global kill switch, or choose arbitrary correction values**.


## v11.62.1 deployment-team fixes

This patch directly addresses the Dell deployment-team pipeline screenshots received on 23 Sep 2026:

- **unit-test job:** governed-update regression tests no longer require `pytest-asyncio`; the real async production flow is exercised through `asyncio.run(...)`, so Dell's shared plain-pytest blueprint works.
- **SCA scan:** `requirements.txt` directly pins `urllib3==2.7.0`, satisfying the strictest reported urllib3 remediation floor while retaining `aia-auth-client==0.0.8`.
- **regression guards:** a deployment-specific test and validator prevent async-pytest dependence or a rollback of the urllib3 security pin.
- **dependency integrity:** CI and Docker builds now run `python -m pip check` after installation.

No business permissions, source-write contracts, approval rules, memory/RSI safety controls, frontend contracts, or source-of-truth behavior were weakened.

## What v11.62 adds

- Persistent trajectory/outcome memory backed by local SQLite (standard library only).
- Deterministic replay lessons derived from accepted/partial/rejected runs.
- PII-free learned skills: successful strategy/model pairings are reused for the same or sufficiently similar evidence-shape signature after minimum evidence thresholds are met.
- Similarity-based replay uses only generic execution-signature tokens; no member identifiers or source values are embedded.
- Bounded strategy exploration/exploitation across static safe prompt profiles.
- Objective run scoring using MCP execution, Dell AIA execution, LLM-as-judge verdict, JSON-contract quality, and latency.
- Bounded champion/challenger selection across a deployment-owned Dell AIA model allow-list (disabled by default until multiple approved models are configured).
- PII-minimized governed-write verification telemetry.
- Memory health/status exposed through the protected Agent API and surfaced in the Data Disparity Agent UI.
- Automatic retention and maximum-record pruning.
- Fail-open behavior: memory failure degrades adaptive learning but does not take down core disparity analysis.
- Challenger model route failures fall back to the configured default champion model; the agent never invents a model route.
- Corrected MCP subprocess module path for the enterprise `src/` folder structure.

## Safety and governance invariants

The following remain deterministic and outside RSI control:

- CPS remains Agentic **read-only**.
- Rewards DB and CrowdTwist writes continue through the existing .NET/manual write implementations.
- Business: one explicit chat approval.
- Customer Support / Technical / Admin: chat approval plus final-review popup.
- Per-user Dry Run and global write kill switch remain authoritative.
- Pre-write re-read, drift checks, read-after-write verification, and audit remain in the governed write path.
- Raw member identifiers, source values, chat text, credentials, and request payloads are not stored in persistent adaptive memory.

## Correct Agent API structure

Production entry point: `src.main:app`.

```text
AgenticDataDisparity.API/
├─ .vscode/
├─ ci-cd/templates/
├─ runtime/
│  ├─ runs/                       # generated run output (ignored)
│  └─ memory/                     # generated SQLite memory (ignored)
├─ scripts/
├─ src/
│  ├─ health/
│  ├─ services/
│  │  ├─ llm_services.py
│  │  └─ disparity_agent/
│  │     ├─ agents/
│  │     ├─ api/
│  │     ├─ connectors/
│  │     └─ memory/               # policy/store/bounded-RSI controller
│  ├─ shared/
│  ├─ resources/
│  ├─ app_settings.py
│  ├─ main.py
│  ├─ models.py
│  ├─ prompt_manager.py
│  ├─ prompts.py
│  └─ routes.py
├─ tests/unit_tests/
├─ .env.example
├─ .gitlab-ci.yml
├─ Dockerfile
├─ pytest.ini
├─ requirements.txt
├─ requirements-dev.txt
└─ VERSION
```

See `Documentation/Reference/FOLDER_STRUCTURE_V11_62.md` and `Documentation/Architecture/V11_62_ADAPTIVE_MEMORY_RSI.md` for the detailed implementation map.

## Start on the Dell Windows integration machine

Prerequisites: .NET 8 SDK, Python 3.11/3.12, Microsoft ODBC Driver 18, Dell network/VPN, and approved Dell credentials/secrets.

Inject secrets through the approved environment/Vault/CI mechanism. Do not commit them to source.

```powershell
.\Start-RUS-v11_62_1.ps1
```

The launcher clean-restores/builds .NET, starts the Agentic API on port 8088, starts .NET on port 49690, validates the source-write bridge and adaptive-memory safety properties, then opens the application.

## Validate the source package

```powershell
python .\scripts\validate_package_v11_62.py
python .\scripts\validate_v11_62_full_parity.py
python .\scripts\validate_deployment_pipeline_fix.py
cd .\AgenticDataDisparity.API
python -m pytest -q
```

For live integration, use the startup launcher so .NET compilation, AutoGen/MCP dependencies, Dell AIA, Spring Config, CPS, Rewards DB, and CrowdTwist connectivity are tested in the actual Dell environment.

## Runtime memory configuration

The defaults are production-conservative and can be overridden by environment variables:

```text
ADAPTIVE_MEMORY_ENABLED=true
ADAPTIVE_MEMORY_RETENTION_DAYS=30
ADAPTIVE_MEMORY_MAX_TRAJECTORIES=5000
ADAPTIVE_MEMORY_REPLAY_LIMIT=3
RSI_ENABLED=true
RSI_MIN_SAMPLES_PER_STRATEGY=3
RSI_EXPLORATION_INTERVAL=12
RSI_LATENCY_TARGET_MS=45000
```

The generated database is `runtime/memory/adaptive_memory.sqlite3`; it is excluded from the source package and source control.

### Optional approved-model champion/challenger configuration

Keep this disabled for a single-model deployment. To evaluate approved on-prem alternatives, configure only model names that are already provisioned in Dell AIA:

```text
DELL_AIA_MODEL=gpt-oss-120b
DELL_AIA_MODEL_CANDIDATES=approved-model-b,approved-model-c
ADAPTIVE_MODEL_SELECTION_ENABLED=true
ADAPTIVE_MODEL_MIN_SAMPLES=3
ADAPTIVE_MODEL_EXPLORATION_INTERVAL=20
ADAPTIVE_SKILL_MIN_SAMPLES=3
```

The default `DELL_AIA_MODEL` remains the fail-safe champion. RSI cannot add names to this allow-list.

## Re-verification hardening

Before deployment re-handoff, the GitLab test job was aligned with its declared artifacts by adding `--junitxml=junit.xml`, and the package-stage archive was updated to include `runtime/` because the production Dockerfile copies that directory. These are CI/deployment reliability fixes; application behavior and v11.62.1 runtime contracts are unchanged.
