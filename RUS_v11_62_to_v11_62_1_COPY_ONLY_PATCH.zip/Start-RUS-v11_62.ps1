$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "RUS v11.62.1 deployment hotfix: forwarding to Start-RUS-v11_62_1.ps1" -ForegroundColor Yellow
& (Join-Path $here "Start-RUS-v11_62_1.ps1") @args
exit $LASTEXITCODE
