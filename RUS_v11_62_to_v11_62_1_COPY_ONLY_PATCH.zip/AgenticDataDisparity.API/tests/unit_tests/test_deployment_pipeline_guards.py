from __future__ import annotations

import ast
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def test_unit_suite_does_not_require_async_pytest_plugin():
    """Shared Dell unit-test blueprints can invoke plain pytest without plugins."""
    offenders = []
    for path in (PROJECT_ROOT / "tests" / "unit_tests").glob("test_*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.AsyncFunctionDef) and node.name.startswith("test_"):
                offenders.append(f"{path.name}:{node.lineno}:{node.name}")
    assert not offenders, "Async pytest tests require a plugin in the shared pipeline: " + ", ".join(offenders)


def test_runtime_manifest_pins_sca_safe_urllib3():
    """Prevent regression below the floor required by the deployment SCA findings."""
    req = (PROJECT_ROOT / "requirements.txt").read_text(encoding="utf-8")
    assert "urllib3==2.7.0" in req
    assert "aia-auth-client==0.0.8" in req


def test_ci_emits_declared_junit_artifact_and_packages_runtime():
    """Keep the shared GitLab handoff self-consistent for test artifacts and Docker context."""
    ci = (PROJECT_ROOT / ".gitlab-ci.yml").read_text(encoding="utf-8")
    assert "--junitxml=junit.xml" in ci
    package_lines = [line.strip() for line in ci.splitlines() if "tar --exclude=" in line]
    assert package_lines, "CI package command is missing"
    assert " runtime " in f" {package_lines[0]} ", "runtime/ must be included in the packaged deployment context"
