from __future__ import annotations

from unittest.mock import AsyncMock
import asyncio
import pytest

from src.services.disparity_agent.api.schemas import SourceOperation, SourceSystem
from src.services.disparity_agent.api.session_store import InMemorySessionStore
from src.services.disparity_agent.api.source_operations import SourceOperationError, SourceOperationService, _can_govern_agentic_write
from src.services.disparity_agent.settings import Settings


async def make_service(tmp_path, role: str):
    store = InMemorySessionStore(ttl_minutes=60, max_messages=100, max_sessions=20)
    state = await store.create({
        "actor": f"{role} User",
        "actor_email": "actor@example.com",
        "actor_role": role,
        "actor_dry_run_enabled": False,
    })
    settings = Settings(
        bootstrap_from_spring_config=False,
        source_write_mode="live",
        source_write_audit_file=tmp_path / "audit.jsonl",
        source_write_audit_unmasked_file=tmp_path / "audit-unmasked.jsonl",
    )
    service = SourceOperationService(settings, store)
    service._read_target = AsyncMock(return_value={
        "connected": True,
        "data_found": True,
        "identity": {"email": "member@example.com", "crowd_twist_id": 123456789},
        "canonical": {"first_name": "Old"},
        "record": {"canonical": {"first_name": "Old"}},
    })
    service._execute_target = AsyncMock(return_value={
        "email": "member@example.com", "success": True, "verified": True,
        "field": "first_name", "before": "Old", "after": "New",
    })
    return service, state


@pytest.mark.parametrize("role", ["Customer", "Customer Support", "Business", "Technical", "Admin"])
def test_every_profile_is_governed_write_enabled(role):
    assert _can_govern_agentic_write(role) is True
    SourceOperationService.require_agentic_write_role(role)


def test_missing_role_fails_closed():
    assert _can_govern_agentic_write(None) is False
    with pytest.raises(SourceOperationError):
        SourceOperationService.require_agentic_write_role(None)


async def _exercise_profile_specific_approval_flow(tmp_path, role, source, field, before, after):
    service, state = await make_service(tmp_path, role)
    service._read_target = AsyncMock(return_value={
        "connected": True, "data_found": True,
        "identity": {"email": "member@example.com", "crowd_twist_id": 123456789},
        "canonical": {field: before}, "record": {"canonical": {field: before}},
    })
    service._execute_target = AsyncMock(return_value={
        "email": "member@example.com", "success": True, "verified": True,
        "field": field, "before": before, "after": after,
    })
    plan = await service.plan_change(
        session_id=state.session_id,
        source=source,
        operation=SourceOperation.UPDATE,
        emails=["member@example.com"],
        field=field,
        new_value=after,
        reason="v11.62 governed update regression",
    )
    after_chat = await service.execute_explicit_chat_command(
        state.session_id,
        plan["change_id"],
        command_text=f"approve {plan['change_id']}",
        actor=state.metadata.get("actor"),
        actor_email=state.metadata.get("actor_email"),
        actor_role=role,
    )
    if role == "Business":
        assert after_chat["status"] == "COMPLETED"
        assert after_chat["required_confirmation_count"] == 1
        service._execute_target.assert_awaited_once()
        return

    assert after_chat["status"] == "AWAITING_CONFIRMATION_2"
    assert after_chat["required_confirmation_count"] == 2
    service._execute_target.assert_not_awaited()

    with pytest.raises(SourceOperationError) as blocked:
        await service.execute_explicit_chat_command(
            state.session_id, plan["change_id"], command_text="yes",
            actor=state.metadata.get("actor"), actor_email=state.metadata.get("actor_email"), actor_role=role,
        )
    assert blocked.value.code == "FINAL_APPROVAL_POPUP_REQUIRED"

    opened = await service.mark_popup_opened(
        state.session_id, plan["change_id"],
        actor=state.metadata.get("actor"), actor_email=state.metadata.get("actor_email"),
    )
    done = await service.confirm_second(
        state.session_id, plan["change_id"], "APPROVE",
        actor=state.metadata.get("actor"), actor_email=state.metadata.get("actor_email"),
        approval_channel="popup", popup_acknowledged=True, audit_acknowledged=True,
        plan_digest=opened["plan_digest"], popup_token=opened["popup_approval_token"],
    )
    assert done["status"] == "COMPLETED"
    service._execute_target.assert_awaited_once()


@pytest.mark.parametrize("role", ["Customer", "Customer Support", "Business", "Technical", "Admin"])
@pytest.mark.parametrize("source,field,before,after", [
    (SourceSystem.CROWD_TWIST, "first_name", "Old", "New"),
    (SourceSystem.REWARDS_DB, "crowd_twist_id", 111111111, 222222222),
])
def test_profile_specific_approval_flow(tmp_path, role, source, field, before, after):
    """Run async production logic without requiring a pytest async plugin.

    Dell's shared unit-test blueprint invokes plain pytest and may install only the
    runtime manifest. Keeping the test itself synchronous makes the regression
    portable across that pipeline while still exercising the real async service.
    """
    asyncio.run(_exercise_profile_specific_approval_flow(tmp_path, role, source, field, before, after))
