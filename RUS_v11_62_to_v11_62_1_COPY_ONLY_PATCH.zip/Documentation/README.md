# RUS v11.62 Documentation

Current production documentation:

- `Reference/FOLDER_STRUCTURE_V11_62.md` — authoritative package/folder layout.
- `Architecture/V11_62_ADAPTIVE_MEMORY_RSI.md` — adaptive memory, replay and bounded-RSI design/safety boundary.
- `Security/SECURITY_V11_62.md` — trust boundaries, credential handling, governed writes and bounded-RSI safety.
- `Validation/V11_62_FULL_E2E_VALIDATION.txt` — generated final validation evidence.
- `Validation/FILE_MANIFEST_SHA256.txt` — generated SHA-256 manifest for shipped files.

Application integration details are also documented in the root `README_FIRST.md`, `AgenticDataDisparity.API/README.md`, and the .NET project README.

## v11.62.1 deployment hotfix

See `Validation/V11_62_1_DEPLOYMENT_PIPELINE_FIX.md` and
`Validation/V11_62_1_FINAL_VALIDATION.txt` for the Dell unit-test/SCA remediation.

Final deployment re-verification: `Validation/V11_62_1_REVERIFIED_HANDOFF.txt`.
